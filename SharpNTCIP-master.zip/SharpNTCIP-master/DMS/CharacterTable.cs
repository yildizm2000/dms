﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpNTCIP.DMS
{
    public class CharacterTable : Table<Tuple<byte,UInt16>, ICharacterEntry>
    {
    }
}
